package bank.client;

/**
 *
 * @author Mike
 */
public class VincentsPauperClient {

    public static void main(String[] args) {
        new BankierApplicatie("vincentspauperbank");
    }
}
