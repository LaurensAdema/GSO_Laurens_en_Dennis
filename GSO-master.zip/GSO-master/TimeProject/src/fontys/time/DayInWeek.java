package fontys.time;

/**
 *
 * @author frankpeeters
 */
public enum DayInWeek {
    SUN,MON,TUE,WED,THU,FRI,SAT;
}
