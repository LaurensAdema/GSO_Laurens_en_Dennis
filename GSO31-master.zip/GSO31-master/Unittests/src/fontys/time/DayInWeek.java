package fontys.time;

/**
 *
 * @author Frank Peeters
 */
public enum DayInWeek {
    SUN,MON,TUE,WED,THU,FRI,SAT;
}
